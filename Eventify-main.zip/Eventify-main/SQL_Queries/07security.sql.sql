/* =========================================================
   07_security.sql
   Skapar roll + anv�ndare och ger SELECT p� views.
   Rollen ska INTE ha direkt SELECT p� tabellerna.
   ========================================================= */

USE EventifyDb;
GO

-- ---------------------------------------------------------
-- 1) Skapa (valfritt) server-login
--    K�r endast om ni har r�ttigheter p� servern.
-- ---------------------------------------------------------
IF NOT EXISTS (SELECT 1 FROM sys.server_principals WHERE name = 'eventify_reader_login')
BEGIN
    PRINT 'Skapar login: eventify_reader_login';
    -- Byt l�senord innan inl�mning om ni vill
    CREATE LOGIN eventify_reader_login
    WITH PASSWORD = 'ChangeMe!12345',
         CHECK_POLICY = OFF,
         CHECK_EXPIRATION = OFF;
END
ELSE
BEGIN
    PRINT 'Login finns redan: eventify_reader_login';
END
GO

-- ---------------------------------------------------------
-- 2) Skapa databas-user kopplad till login
-- ---------------------------------------------------------
IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = 'eventify_reader_user')
BEGIN
    PRINT 'Skapar user: eventify_reader_user';
    CREATE USER eventify_reader_user FOR LOGIN eventify_reader_login;
END
ELSE
BEGIN
    PRINT 'User finns redan: eventify_reader_user';
END
GO

-- ---------------------------------------------------------
-- 3) Skapa roll
-- ---------------------------------------------------------
IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = 'eventify_reader_role' AND type = 'R')
BEGIN
    PRINT 'Skapar roll: eventify_reader_role';
    CREATE ROLE eventify_reader_role;
END
ELSE
BEGIN
    PRINT 'Roll finns redan: eventify_reader_role';
END
GO

-- ---------------------------------------------------------
-- 4) L�gg user i rollen
-- ---------------------------------------------------------
IF NOT EXISTS
(
    SELECT 1
    FROM sys.database_role_members rm
    JOIN sys.database_principals r ON r.principal_id = rm.role_principal_id
    JOIN sys.database_principals u ON u.principal_id = rm.member_principal_id
    WHERE r.name = 'eventify_reader_role'
      AND u.name = 'eventify_reader_user'
)
BEGIN
    PRINT 'L�gger eventify_reader_user i eventify_reader_role';
    ALTER ROLE eventify_reader_role ADD MEMBER eventify_reader_user;
END
ELSE
BEGIN
    PRINT 'User �r redan medlem i rollen';
END
GO

-- ---------------------------------------------------------
-- 5) S�kerst�ll att rollen INTE har SELECT p� tabellerna
--    (om den r�kat f� det tidigare)
-- ---------------------------------------------------------
DENY SELECT ON dbo.Customers TO eventify_reader_role;
DENY SELECT ON dbo.Venues    TO eventify_reader_role;
DENY SELECT ON dbo.Tags      TO eventify_reader_role;
DENY SELECT ON dbo.Events    TO eventify_reader_role;
DENY SELECT ON dbo.Orders    TO eventify_reader_role;
DENY SELECT ON dbo.Tickets   TO eventify_reader_role;
DENY SELECT ON dbo.EventTags TO eventify_reader_role;
GO

-- ---------------------------------------------------------
-- 6) Ge SELECT p� views (rollen f�r l�sa dessa)
-- ---------------------------------------------------------
GRANT SELECT ON dbo.vPublicEvents      TO eventify_reader_role;
GRANT SELECT ON dbo.vReportEventSales  TO eventify_reader_role;
GO

-- ---------------------------------------------------------
-- 7) (Valfritt) Snabbtest: visa r�ttigheter (metadata)
-- ---------------------------------------------------------
PRINT 'Klart: eventify_reader_role har SELECT p� views men DENY p� tabeller.';
GO
